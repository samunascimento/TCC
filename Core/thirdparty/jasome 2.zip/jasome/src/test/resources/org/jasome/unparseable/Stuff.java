package org.jasome.unparseable;

class Stuff {
    purblac void doThings() {

    }
}