package org.jasome.metrics.calculators

import spock.lang.Specification

class WeightedMethodsCalculatorSpec extends Specification{
    def "calculate simple metric"() {
        //TODO: need a way to do tests that depend on other calculations being done
    }
}
